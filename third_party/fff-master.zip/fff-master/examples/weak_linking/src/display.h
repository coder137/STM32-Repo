#pragma once
#include "error.h"

bool display_init();
void display_update( const char* info );
